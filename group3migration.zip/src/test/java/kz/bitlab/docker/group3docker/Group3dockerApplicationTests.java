package kz.bitlab.docker.group3docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Group3dockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
