INSERT INTO car (name, max_speed)
VALUES
       ('Mercedes E280', 220),
       ('Toyota Camry 70', 250),
       ('Lexus RX 330', 200),
       ('KIA RIO', 190);
