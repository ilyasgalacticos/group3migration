ALTER TABLE car
CHANGE COLUMN max_speed speed int(11);