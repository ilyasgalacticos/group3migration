CREATE TABLE car (
    id int(11) auto_increment,
    name varchar(255),
    max_speed int(11),
    primary key (id)
);