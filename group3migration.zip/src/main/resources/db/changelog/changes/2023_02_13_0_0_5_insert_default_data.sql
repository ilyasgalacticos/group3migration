TRUNCATE TABLE car;

INSERT INTO car (name, speed, engine_volume)
VALUES
       ('Mercedes E280', 220, 2.4),
       ('Toyota Camry 70', 250, 1.6),
       ('Lexus RX 330', 200, 3.3),
       ('KIA RIO', 190, 1.9);