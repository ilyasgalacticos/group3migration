ALTER TABLE car
ADD COLUMN engine_volume float;