package kz.bitlab.docker.group3docker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group3dockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Group3dockerApplication.class, args);
	}

}
